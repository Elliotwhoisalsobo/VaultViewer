﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VaultViewer.ServiceLayer;
using VaultViewer.Business;
using VaultViewer.DataAccessLayer;
using System.Configuration;
using System.Windows.Controls;
using System.IO;

//using DevExpress.Mvvm; // external library
namespace VaultViewer.ServiceLayer
{
    public class UserpanelService
    {


    }
}

