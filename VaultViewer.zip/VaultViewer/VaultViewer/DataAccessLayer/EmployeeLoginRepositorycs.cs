﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaultViewer.DataAccessLayer
{
    internal class EmployeeLoginRepositorycs
    {
        // Constructor <-- database config as arguement 
        // method employeelogin exists <-- implement as bool for mysql exist
        // call method from loginservice --> employeelogin (add unique logic based on bool)
        // solve login method later
    }
}
